package com.example.noteapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.noteapp.db.Category;
import com.example.noteapp.db.Note;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {
    private List<Note> mDataset;
    private Context context;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // create a new view
        context = parent.getContext();
        View v = (View) LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_1 , parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.notename.setText(mDataset.get(position).title);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context,AddNoteActivity.class)
                        .putExtra("noteno",Integer.toString(mDataset.get(position).noteid)));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public NoteAdapter(List<Note> myDataset) {
        mDataset = myDataset;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView notename;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            notename = itemView.findViewById(android.R.id.text1);
        }



    }
}
