package com.example.noteapp.db.Dao;

import androidx.room.Dao;
import androidx.room.Index;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.noteapp.db.Category;

import java.util.List;

@Dao
public interface CatDao {

    @Query("SELECT * FROM category")
    List<Category> getAll();

    @Insert
    long addCategory(Category cat);




}
