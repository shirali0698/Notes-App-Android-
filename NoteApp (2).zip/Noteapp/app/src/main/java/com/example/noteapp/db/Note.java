package com.example.noteapp.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Note {
    @PrimaryKey(autoGenerate = true)
    public int noteid;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "description")
    public String description;

    @ColumnInfo(name = "imageUrl")
    public String imageUrl;

    @ColumnInfo(name = "voicenote")
    public String voicenote;

    @ColumnInfo(name = "location")
    public String location;

    @ColumnInfo(name = "parentCat")
    public String parentCat;

    public Note(String title, String desc, String imageUrl, String location, String mp3Url, String parentCat){
        this.title = title;
        this.description = desc;
        this.imageUrl = imageUrl;
        this.location = location;
        this.voicenote = mp3Url;
        this.parentCat = parentCat;
    }

    public Note(){}

}
