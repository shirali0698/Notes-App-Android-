package com.example.noteapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.noteapp.db.Category;

import java.util.List;

public class CatAdapter extends RecyclerView.Adapter<CatAdapter.ViewHolder> {
    private List<Category> mDataset;
    private Context context;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // create a new view
        context = parent.getContext();
        View v = (View) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.catname_recyclerview_item, parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.catname.setText(mDataset.get(position).title);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context,NoteActivity.class)
                .putExtra("catno",Integer.toString(mDataset.get(position).catid)));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public CatAdapter(List<Category> myDataset) {
        mDataset = myDataset;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView catname;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            catname = itemView.findViewById(R.id.catname_recyclerview);
        }


    }
}
