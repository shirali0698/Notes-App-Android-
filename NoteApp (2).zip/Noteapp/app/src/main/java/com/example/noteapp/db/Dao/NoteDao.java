package com.example.noteapp.db.Dao;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.noteapp.db.Note;

import java.util.List;

@Dao
public interface NoteDao {
    @Query("SELECT * FROM Note")
    List<Note> getAll();

    @Query("SELECT * FROM Note WHERE noteid LIKE :noteno")
    Note getNote(String noteno);

    @Query("SELECT * FROM Note WHERE parentCat LIKE :parentCat")
    List<Note> getCatNotes(String parentCat);

    @Insert
    long addNote(Note note);



}
