package com.example.noteapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.noteapp.db.AppDataBase;
import com.example.noteapp.db.Note;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.UUID;

public class AddNoteActivity extends FragmentActivity implements OnMapReadyCallback {

    String catno, noteno;
    Button saveBtn, selectImageBtn, btnRecord, btnStop,btnPlay;
    String pathSave = "";
    MediaRecorder  mediaRecorder;
    MediaPlayer mediaPlayer;
    final int REQUEST_PERMISSION_CODE = 1000;

    EditText title_et, desc_et;
    ImageView select_image;
    String selected_image_url = "";

    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);
        catno = getIntent().getExtras().getString("catno");
        noteno = getIntent().getExtras().getString("noteno");
        title_et = (EditText) findViewById(R.id.notetitle);
        desc_et = (EditText) findViewById(R.id.notedesc);
        select_image = (ImageView) findViewById(R.id.noteImage);
        saveBtn = (Button) findViewById(R.id.saveNote);
        selectImageBtn = (Button) findViewById(R.id.select_image);
        if (noteno != null) {
            AppDataBase db = AppDataBase.getInstance(getApplicationContext());
            Note note = db.noteDao().getNote(noteno);
            title_et.setText(note.title.toString());
            desc_et.setText(note.description);
            Picasso.get().load(note.imageUrl).into(select_image);
        }


        selectImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String note_title = title_et.getText().toString();
                String note_desc = desc_et.getText().toString();
                if (note_desc.isEmpty() || note_title.isEmpty() || selected_image_url.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Enter all fields", Toast.LENGTH_LONG).show();
                    return;
                }
                saveNote(note_title, note_desc, selected_image_url, catno);

            }
        });

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();

        if(!checkPermissionFromDevice())
            requestPermission();

        btnPlay = (Button)findViewById(R.id.btnPlay);
        btnRecord = (Button)findViewById(R.id.btnStartRecord);
        btnStop = (Button)findViewById(R.id.btnStopRecord);

            btnRecord.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(checkPermissionFromDevice()) {
                        pathSave = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + UUID.randomUUID().toString() + "_audio_record.3gp";
                        setUpMediaRecorder();
                        try{
                            mediaRecorder.prepare();
                            mediaRecorder.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        btnPlay.setEnabled(false);

                        Toast.makeText(AddNoteActivity.this,"Recording...",Toast.LENGTH_SHORT).show();


                    }
                    else {
                        requestPermission();
                    }
                }
            });


           btnStop.setOnClickListener((view) -> {
                 mediaRecorder.stop();
                 btnStop.setEnabled(false);
                 btnPlay.setEnabled(true);
                 btnRecord.setEnabled(true);


           });

           btnPlay.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   btnStop.setEnabled(false);
                   btnRecord.setEnabled(false);

                   mediaPlayer = new MediaPlayer()
;
               try {
                   mediaPlayer.setDataSource(pathSave);
                   mediaPlayer.prepare();
               } catch (IOException e) {
                   e.printStackTrace();
               }
               mediaPlayer.start();
               Toast.makeText(AddNoteActivity.this,"Playing", Toast.LENGTH_SHORT).show();

               }
           });



        
    }

    private void setUpMediaRecorder() {
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        mediaRecorder.setOutputFile(pathSave);
    }

    private boolean checkPermissionFromDevice() {
        int writ_external_storage_result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int record_audio_result = ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO);
        return writ_external_storage_result == PackageManager.PERMISSION_GRANTED && record_audio_result == PackageManager.PERMISSION_GRANTED;
    }

  private void requestPermission() {
        ActivityCompat.requestPermissions(this,new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO
        },REQUEST_PERMISSION_CODE);
    }



    private void fetchLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new  String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(),currentLocation.getLatitude()+""+currentLocation.getLongitude(),Toast.LENGTH_SHORT).show();
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
                    supportMapFragment.getMapAsync(AddNoteActivity.this);
                }
            }
        });
    }

    private void saveNote(String note_title, String note_desc, String selected_image_url, String parentCat) {
        AppDataBase db = AppDataBase.getInstance(getApplicationContext());
         db.noteDao().addNote(new Note(note_title,note_desc,selected_image_url,
                null,null,catno));
    }


    public void selectImage()
    {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 99);


    }

    private void goToMain() {
        Intent i = new Intent(this,NoteActivity.class);
        startActivity(i);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 99) {

                Uri selectedImageURI = data.getData();

                selected_image_url = selectedImageURI.toString();

                Picasso.get().load(selectedImageURI).into(select_image);
            }
    }
}

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,5));
        googleMap.addMarker(markerOptions);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case REQUEST_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    fetchLastLocation();
                    break;
                }
            case REQUEST_PERMISSION_CODE:
            {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this,"Permission Denieed",Toast.LENGTH_SHORT).show();
            }
                break;
        }
    }
}
