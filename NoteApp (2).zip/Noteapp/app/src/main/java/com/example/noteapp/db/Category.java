package com.example.noteapp.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Category {

    @PrimaryKey(autoGenerate = true)
    public int catid;

    @ColumnInfo(name = "title")
    public String title;



    @ColumnInfo(name = "noteCount")
    public int noteCount;

    public Category(String title){
        this.title = title;
        this.noteCount = 0;
    }

}
