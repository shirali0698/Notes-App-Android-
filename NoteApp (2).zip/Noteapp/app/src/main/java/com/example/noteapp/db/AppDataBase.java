package com.example.noteapp.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.noteapp.db.Dao.CatDao;
import com.example.noteapp.db.Dao.NoteDao;

@Database(entities = {Category.class, Note.class}, version = 3)
public abstract class AppDataBase extends RoomDatabase {
    public abstract CatDao catDao();
    public abstract NoteDao noteDao();

    private static  AppDataBase INSTANCE = null;


    public static AppDataBase getInstance(Context c){
        if(INSTANCE == null)
        {
            INSTANCE = Room.databaseBuilder(c,
                    AppDataBase.class, "mydb")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }

        return INSTANCE;
    }
}

